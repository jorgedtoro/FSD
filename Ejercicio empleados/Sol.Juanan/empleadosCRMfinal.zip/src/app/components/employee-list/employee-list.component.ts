import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/interfaces/employee.interface';
import { DepartmentsService } from 'src/app/services/departments.service';
import { EmployeesService } from 'src/app/services/employees.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  arrEmployees: Employee[] = [];
  constructor(
    private employeesServices: EmployeesService,
    private departmentsService: DepartmentsService
  ) { }

  ngOnInit(): void {
    this.arrEmployees = this.employeesServices.getAll()
    let arrDepartments = this.departmentsService.getAll()
    console.log(arrDepartments);
  }

}
