import { Injectable } from '@angular/core';
import { Employee } from '../interfaces/employee.interface';
import { EMPLOYEES } from '../db/employees.db';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  private id: number = 3;
  private arrEmployees: Employee[] = []
  constructor() {
    this.arrEmployees = EMPLOYEES
  }

  getAll(): Employee[] {
    return this.arrEmployees;
  }

  getById(pId: number): Employee | undefined {
    return this.arrEmployees.find(employee => employee.id === pId);
  }

  create(pEmployee: Employee): any {
    pEmployee.id = this.id
    let posicion = this.arrEmployees.push(pEmployee);
    this.id++;
    if (posicion) {
      return { success: 'ok' }
    } else {
      return { error: 'No se ha insertado el empleado' }
    }
  }
}
