export interface Employee {
  id?: number;
  name: string;
  surname: string;
  dni: string;
  email: string;
  photo: string;
  department: number;
  status: boolean;
}
