export interface Department {
  id: number;
  title: string;
  numEmployees: number
}
