document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.querySelector('#contact-form');

    const fetchHandler = ({success, message}) => {
        const alert = document.createElement('div');
        alert.classList.add('alert');
        alert.classList.add(`alert--${success}`);
        alert.innerText = message;
        contactForm.prepend(alert);
    }
    
    contactForm.addEventListener('submit', (event) => {
        event.preventDefault();
        fetch("https://formsubmit.co/ajax/3d5d1597340d0b96c777d79856736459", {
            method: "POST",
            body: new FormData(event.target)
        }).then(res => res.json()).then(fetchHandler)
    })

    
});