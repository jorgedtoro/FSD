const scriptsLoaded = [];

const scriptLoader = (url) => {
    return new Promise((resolve, reject) => {
        if (scriptsLoaded.includes(url)) {
            resolve();
        } else {
            scriptsLoaded.push(url);
            const s = document.createElement('script');
            s.src = url;
            s.onload = resolve;
            s.onerror = reject;
            document.body.appendChild(s);
        }
    });
};

document.addEventListener('DOMContentLoaded', ()=> {
    scriptLoader("https://cdn.jsdeliv")
        .then(res => console.log("ha ido bien cargando bootstrap"))
        .catch(res => console.log("algo ha ido mal cargando bootstrap"));
});