document.addEventListener("DOMContentLoaded", () => {
    const listadoEl = document.querySelector("#listado");
    const detalleEl = document.querySelector("#detalle");
    const listado = new ListadoSW(listadoEl);
    const detalle = new DetalleSW(detalleEl);

    listado.init();
    document.addEventListener("detalleSWPaint", event => {
        detalle.paint(event.id);
    });
});