class DetalleSW {
    #element
    #people

    constructor(element) {
        this.#element = element;
    }

    #paintDetail() {
        console.log(this.#people);
        this.#element.innerHTML = "";
        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
            <p>Nombre: ${this.#people.name}</p>
            <p>Altura: ${this.#people.height}</p>
        `;
        this.#element.appendChild(wrapper);
    }

    paint(id) {
        fetch(`https://swapi.dev/api/people/${id}`)
        .then((res) => res.json())
        .then((res) => {
            this.#people = res;
            this.#paintDetail();
        });
    }
}