const OMDBAPIKEY = "7da6b168";

document.addEventListener('DOMContentLoaded', () => {

    const list = document.querySelector("#list");

    const paintPage = (page) => {
        list.innerHTML = "";
        let pageHTML = "";
        page.Search.forEach(result => {
            pageHTML += `<div>${result.Title}</div>`;
        });
        list.innerHTML = pageHTML;
    }

    const apiSearch = (query) => {
        fetch(`https://www.omdbapi.com/?apikey=${OMDBAPIKEY}&s=${query}`)
            .then(res => res.json())
            .then(obj => paintPage(obj));
    }

    const form = document.querySelector('#search');
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const formdata = new FormData(event.target);
        apiSearch(formdata.get('s'));
    });
});