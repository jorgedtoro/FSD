class ListadoSW {
    #element
    #people
    #ctx

    constructor(element) {
        this.#element = element;
        this.#ctx = document.getElementById('myChart').getContext('2d');
    }

    #loadingElement(toggle) {
        this.#element.setAttribute('data-loading', toggle);
    }

    #peopleClickHandler(event) {
        const id = event.target.getAttribute('data-id');
        const dispatch = new Event("detalleSWPaint");
        dispatch.id = id;
        document.dispatchEvent(dispatch);
    }

    #paginationClickHandler(event) {
        event.preventDefault();
        const href = event.target.href;
        this.#getPeople(href);
    }

    #paintChart() {
        const labels = this.#people.results.map(people => people.name);
        const data = this.#people.results.map(people => people.height);

        new Chart(this.#ctx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Heights',
                    data,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    #paintList() {
        this.#element.innerHTML = "";
        
        // Listado
        const list = document.createElement('div');
        this.#people.results.forEach((result, index) => {
            const people = document.createElement('p');
            people.innerText = result.name;
            people.setAttribute('data-id', index + 1);
            people.addEventListener('click', (event) => this.#peopleClickHandler(event));
            list.appendChild(people);
        });
        this.#element.appendChild(list);

        // Paginación
        const pagination = document.createElement('div');

        if (this.#people.previous) {
            const prev = document.createElement('a');
            prev.innerText = "prev";
            prev.href = this.#people.previous;
            prev.addEventListener("click", (event) => this.#paginationClickHandler(event))
            pagination.appendChild(prev);
        }

        if (this.#people.next) {
            const next = document.createElement('a');
            next.innerText = "next";
            next.href = this.#people.next;
            next.addEventListener("click", (event) => this.#paginationClickHandler(event))
            pagination.appendChild(next);
        }

        this.#element.appendChild(pagination);
    }

    #getPeople(url = "https://swapi.dev/api/people") {
        this.#loadingElement(true);
        fetch(url)
        .then((res) => res.json())
        .then((res) => {
            this.#people = res;
            this.#loadingElement(false);
            this.#paintList();
            this.#paintChart();
        });
    }

    init() {
        this.#getPeople();
    }
}