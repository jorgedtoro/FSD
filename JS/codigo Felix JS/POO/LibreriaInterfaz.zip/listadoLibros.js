const listadoLibros =  [
    {
        titulo: "Todas esas cosas que te diré mañana",
        autor: "Elísabet Benavent",
        isbn: "978-84-9129-597-6",
        peso: 642,
        genero: "Ensayos literarios",
    },
    {
        titulo: "El peligro de estar cuerda",
        autor: "Rosa Montero",
        isbn: "978-84-322-4064-5",
        peso: 484,
    }
];