export interface Contacto {
  id: number;
  name: string;
  phone: number
}
