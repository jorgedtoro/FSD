import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;

  constructor(
    private usersServices: UsersService,
    private router: Router
  ) {
    this.registerForm = new FormGroup({
      name: new FormControl("", []),
      surname: new FormControl("", []),
      username: new FormControl("", []),
      password: new FormControl("", []),
      mail: new FormControl("", []),
      address: new FormControl("", []),
      age: new FormControl("", []),
    }, [])
  }

  ngOnInit(): void {
  }

  async getDataForm() {
    try {
      const response = await this.usersServices.register(this.registerForm.value)
      if (response.success) {
        //redirigir a login
        this.router.navigate(['/login'])
      } else {
        alert(response.error)
      }
    } catch (err) {
      console.log(err);
    }

  }

}
