import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-premio',
  templateUrl: './premio.component.html',
  styleUrls: ['./premio.component.css']
})
export class PremioComponent implements OnInit {

  url: string = "";
  constructor(
    private usersServices: UsersService,
    private router: Router
  ) { }

  async ngOnInit(): Promise<void> {
    let response = await this.usersServices.getPremio();
    if (response.success) {
      let data = response.success.split(': ')[1];
      this.url = data.split(" ")[0];
    } else {
      alert(response.error)
    }
  }

  logout() {
    localStorage.removeItem('user-token')
    this.router.navigate(['/login'])
  }

}
