export interface User {
  id?: number;
  name: string;
  surname: string;
  username: string;
  password: string;
  mail: string;
  address: string;
  age: number;
}
