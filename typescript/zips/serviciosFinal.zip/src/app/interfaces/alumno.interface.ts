export interface Alumno {
  id: number;
  nombre: string;
  edad: number;
  email: string;
  curso: string;
}
