import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-model',
  templateUrl: './form-model.component.html',
  styleUrls: ['./form-model.component.css']
})
export class FormModelComponent implements OnInit {

  formModel: FormGroup
  constructor() {
    this.formModel = new FormGroup({
      nombre: new FormControl('', [
        Validators.required,
        Validators.minLength(3)
      ]),
      edad: new FormControl('', [
        this.edadValidator
      ]),
      dni: new FormControl('', [
        this.dnivalidator
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/)
      ]),
      password: new FormControl('', [
        Validators.required,
      ]),
      repeatpassword: new FormControl('', []),
    }, [this.checkPassword])
  }

  checkPassword(pFormValue: AbstractControl) {
    const password: string = pFormValue.get('password')?.value;
    const repeatpassword: string = pFormValue.get('repeatpassword')?.value;
    if (password !== repeatpassword) {
      return { 'checkpassword': true }
    } else {
      return null
    }
  }



  dnivalidator(pControlName: AbstractControl): any {
    //validar un dni no solo consiste en que tenga 8 numero y letra si no que la letra tiene que coincider con la posicion que resuelve dividir el numero del dni por 23 syu resto me da la posicion en un array letras
    const letrasDni: string[] = ["T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"];
    const dni = pControlName.value;
    const exp = /^\d{8}[A-Z]{1}/

    if (exp.test(dni)) {
      //el dni esta bien escrito pero eso significa que sea valido
      const numero: number = parseInt(dni.substring(0, dni.length - 1));
      const letra: string = dni.at(-1)
      const position: number = numero % 23;

      return (letra !== letrasDni[position]) ? { 'dnivalidator': 'La letra no corresponde con al dni' } : null;


    } else {
      return { 'dnivalidator': 'formato de dni incorrecto' }
    }

  }

  edadValidator(pControlName: AbstractControl): any {
    const edad: number = parseInt(pControlName.value)
    if (isNaN(edad)) {
      return { 'edadvalidator': 'La edad introducida no es un numero' }
    } else if (edad < 18 || edad > 65) {
      return { 'edadvalidator': 'La edad tiene que estar comprendida entre 18 y 65 años' }
    }

    return null
  }

  ngOnInit(): void {
  }

  getDataForm() {
    if (this.formModel.valid) {
      console.log(this.formModel.value)
    } else {
      alert('el formulario no esta bien relleno')
    }

  }

  checkControl(pControlName: string, pError: string): boolean {
    if (this.formModel.get(pControlName)?.hasError(pError) && this.formModel.get(pControlName)?.touched) {
      return true;
    } else {
      return false;
    }
  }

}
