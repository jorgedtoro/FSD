### Como crear un input para pasar informacion del padre al hijo.
  - Inputs
     
      Paso 1 - en el etiqueta personalizada o selector del componente hijo tengo que cargar un propiedad de html personaliza, le pongo el nomnbre que yo quiera, y esa propiedad el paso el dato que tiene que existir como propiedad de clase en el componente padre.

      Paso 2: En el componente destino/hijo tengo que crear un propiedad que es del mismo tipo y que tiene el mismo nombre que la padre pero decorada con un @Input(), esto me indica que es propieda es un input y que estará diponible cuando se cargue componente.

  - Outputs
     
     paso 1: Crear una propiedad personalizada decorada con @Ouput(). Esta propiedad es un Evento personalizado es de tipo EventEmitter

     paso 2: Inicializado la propiedad creada en el constructor como new EventEmitter();

     paso 3: Recogo el valor que quiero enviar y lo emito al padre a traves un evento emit del Output.

     pase 4: en la etiqueta del componente creo un evento personalizado ()="", llamado exactamente igual al valor de la propiedad Output, que ejecuta una funcion que recibe como parametro $event, ya que necesitamos recoger el valor del propio componente.

     paso 5: creo la funcion en el componente padre y recojo el valor del $event, ya es el valor que necesito.
