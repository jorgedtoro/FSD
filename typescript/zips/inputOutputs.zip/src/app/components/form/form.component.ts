import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  miNumero: number = 0;
  @Output() numeroEnviado: EventEmitter<number>
  constructor() {
    this.numeroEnviado = new EventEmitter();
  }

  ngOnInit(): void {
  }

  recogerData() {
    //console.log(this.miNumero);
    //emito el numero captura al padre.
    this.numeroEnviado.emit(this.miNumero);
  }

}
