import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-numeros',
  templateUrl: './lista-numeros.component.html',
  styleUrls: ['./lista-numeros.component.css']
})
export class ListaNumerosComponent implements OnInit {

  lis: string = "";
  @Input() numeros: number[] = [];
  constructor() {
    console.log('constructor ciclo de vida')
  }

  ngOnChanges(): void {
    console.log('ngOnChanges ciclo de vida')
  }

  ngOnInit(): void {
    //console.log('estoy en lista numeros', this.numeros)
    console.log('ngOnInit ciclo de vida')
    this.cargarDatos();
  }

  //ngDoCheck responde cada vez que interactuamos con el interfaz
  ngDoCheck(): void {
    console.log('ngDoCheck ciclo de vida')
    this.cargarDatos();
  }

  ngAfterViewInit(): void {
    console.log('afterviewinit ciclo de vida')
  }

  cargarDatos(): void {
    this.lis = ""
    this.numeros.forEach(numero => this.lis += `<li>${numero}</li>`);
  }

}
