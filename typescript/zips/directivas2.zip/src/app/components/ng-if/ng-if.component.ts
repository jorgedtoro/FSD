import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-if',
  templateUrl: './ng-if.component.html',
  styleUrls: ['./ng-if.component.css']
})
export class NgIfComponent implements OnInit {

  seccionActual: string = 'experiencia'
  constructor() { }

  ngOnInit(): void {
  }

  cargarSeccion(seccion: string): void {
    this.seccionActual = seccion;

  }

}
