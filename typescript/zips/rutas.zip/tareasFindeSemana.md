cargar la opiniones por categoria en cada trabajo de todos lo clientes.
