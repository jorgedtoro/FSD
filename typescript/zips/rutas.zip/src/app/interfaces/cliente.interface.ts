export interface Cliente {
  id: number;
  nombre: string;
  categoria: string;
}
