export interface Opinion {
  id: number;
  opinion: string;
  contacto: string;
  categoria: string;
}
