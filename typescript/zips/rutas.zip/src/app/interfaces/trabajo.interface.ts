export interface Trabajo {
  id: number;
  titulo: string;
  texto: string;
  url: string;
}
