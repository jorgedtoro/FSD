import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-style',
  templateUrl: './ng-style.component.html',
  styleUrls: ['./ng-style.component.css']
})
export class NgStyleComponent implements OnInit {

  fontSize: number = 10;
  constructor() { }
  estilosParrafo: any = {};
  propiedadCss: string = "";
  valorCss: string = "";
  ngOnInit(): void {
  }

  cambiarFuente($event: any) {
    this.fontSize = $event.target.value;
  }

  cambiarEstilos() {
    // this.estilosParrafo.padding = '20px'
    this.estilosParrafo[this.propiedadCss] = this.valorCss
    console.log(this.estilosParrafo)
  }

}
