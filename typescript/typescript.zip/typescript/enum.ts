enum Talla {
    sm,
    m,
    l,
    xl,
    xxl
}

console.log(Talla)
console.log(Talla['0']) //sm
console.log(Talla.xl) // 3