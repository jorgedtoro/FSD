var Talla;
(function (Talla) {
    Talla[Talla["sm"] = 0] = "sm";
    Talla[Talla["m"] = 1] = "m";
    Talla[Talla["l"] = 2] = "l";
    Talla[Talla["xl"] = 3] = "xl";
    Talla[Talla["xxl"] = 4] = "xxl";
})(Talla || (Talla = {}));
console.log(Talla);
