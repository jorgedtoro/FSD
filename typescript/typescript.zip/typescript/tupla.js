//Tupla es una array de longitud fija y elementos de diferente tipo.
var tupla = ['Juan', 40, true];
var valor = 'hola';
valor = 2;
console.log(tupla);
console.log(tupla[0]);
